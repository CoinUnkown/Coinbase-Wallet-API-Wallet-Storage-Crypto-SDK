#ifndef PROGRESS_H
#define PROGRESS_H

void PROGRESS(float progress);

#endif
